<?php
require("utils.php");
$fileURL=getJustBasenameURL();
doPage("content/$fileURL");
?>
