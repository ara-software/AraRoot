<?php
virtual("/monitor/headers/lastEvent.shtml");
?>

<table border="1" align="center" width="50%">
<tr>
<td><a name="canAverageFFTOneHour" align="center"><h3>Average FFT</h3></a>
<a href="canAverageFFTOneHour.php" target="_top">
<img src="canAverageFFTOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canWaveformRMSTimeOneHour" align="center"><h3>Waveform RMS</h3></a>
<a href="canWaveformRMSTimeOneHour.php" target="_top"> 
<img src="canWaveformRMSTimeOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canWaveformSNRTimeOneHour" align="center"><h3>Waveform SNR</h3></a>
<a href="canWaveformSNRTimeOneHour.php" target="_top"> 
<img src="canWaveformSNRTimeOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
</tr>
<tr>
<td><a name="canAverageFFTTimeOneHour" align="center"><h3>Average FFT v Time</h3></a>
<a href="canAverageFFTTimeOneHour.php" target="_top">
<img src="canAverageFFTTimeOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canEventRateOneHour" align="center"><h3>Event Rate</h3></a>
<a href="canEventRateOneHour.php" target="_top">
<img src="canEventRateOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canDeadTimeOneHour" align="center"><h3>Dead Time</h3></a>
<a href="canDeadTimeOneHour.php" target="_top"> 
<img src="canDeadTimeOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
</tr>
<tr>
<td><a name="canEventNumberOneHour" align="center"><h3>Event Number</h3></a>
<a href="canEventNumberOneHour.php" target="_top">
<img src="canEventNumberOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canPpsNumOneHour" align="center"><h3>PPS Num</h3></a>
<a href="canPpsNumOneHour.php" target="_top"> 
<img src="canPpsNumOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canRcoCountOneHour" align="center"><h3>RCO Count</h3></a>
<a href="canRcoCountOneHour.php" target="_top"> 
<img src="canRcoCountOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
</tr>
<tr>
<td><a name="canRoVddOneHour" align="center"><h3>ROVDD</h3></a>
<a href="canRoVddOneHour.php" target="_top">
<img src="canRoVddOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canTrigTypeBitOneHour" align="center"><h3>Trigger type</h3></a>
<a href="canTrigTypeBitOneHour.php" target="_top"> 
<img src="canTrigTypeBitOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canTrigPatternOneHour" align="center"><h3>Trigger Pattern</h3></a>
<a href="canTrigPatternOneHour.php" target="_top">
<img src="canTrigPatternOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
</tr>
<tr>
<td><a name="canUnixTimeUsOneHour" align="center"><h3>Sub Second Time</h3></a>
<a href="canUnixTimeUsOneHour.php" target="_top"> 
<img src="canUnixTimeUsOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canTrigPatternTimeOneHour" align="center"><h3>Trigger Pattern</h3></a>
<a href="canTrigPatternTimeOneHour.php" target="_top">
<img src="canTrigPatternTimeOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
</tr>
<tr>
<td><a name="canCalibStatusBitOneHour" align="center"><h3>Calib Status Bit</h3></a>
<a href="canCalibStatusBitOneHour.php" target="_top">
<img src="canCalibStatusBitOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canErrorFlagOneHour" align="center"><h3>Error  Flag</h3></a>
<a href="canErrorFlagOneHour.php" target="_top">
<img src="canErrorFlagOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
<td><a name="canPriorityOneHour" align="center"><h3>Priority</h3></a>
<a href="canPriorityOneHour.php" target="_top">
<img src="canPriorityOneHour.png" alt="Resized PNG graphic" title="Click to view" border="1" width="158" height="150" hspace="10" /></a>
</td>
</tr>
</table>



