<?php
require("utils.php");
doPage("content/canTrigTypeBit.php");
?>
