<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canTrigPatternTime\"><h3>Trigger Pattern</h3></a>
<img style=\"border:outset\" src=\"$rundir/canTrigPatternTime.png\" alt=\"canTrigPatternTime\" />'";
?>
