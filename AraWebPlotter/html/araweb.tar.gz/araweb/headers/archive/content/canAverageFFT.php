<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canAverageFFT\"><h3>Average FFT</h3></a>
<img style=\"border:outset\" src=\"$rundir/canAverageFFT.png\" alt=\"canAverageFFT\" />'";
?>
