<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canWaveformRMSTime\"><h3>Waveform RMS</h3></a>
<img style=\"border:outset\" src=\"$rundir/canWaveformRMSTime.png\" alt=\"canWaveformRMSTime\" />'";
?>
