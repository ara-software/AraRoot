<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canRcoCount\"><h3>RCO Count</h3></a>
<img style=\"border:outset\" src=\"$rundir/canRcoCount.png\" alt=\"canRcoCount\" />'";
?>
