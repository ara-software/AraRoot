<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canEventRate\"><h3>Event Rate</h3></a>
<img style=\"border:outset\" src=\"$rundir/canEventRate.png\" alt=\"canEventRate\" />'";
?>
