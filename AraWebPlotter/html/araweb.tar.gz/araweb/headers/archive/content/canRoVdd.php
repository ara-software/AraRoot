<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canRoVdd\"><h3>ROVDD</h3></a>
<img style=\"border:outset\" src=\"$rundir/canRoVdd.png\" alt=\"canRoVdd\" />'";
?>
