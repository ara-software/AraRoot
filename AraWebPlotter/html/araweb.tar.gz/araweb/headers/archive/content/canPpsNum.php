<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canPpsNum\"><h3>PPS Num</h3></a>
<img style=\"border:outset\" src=\"$rundir/canPpsNum.png\" alt=\"canPpsNum\" />'";
?>
