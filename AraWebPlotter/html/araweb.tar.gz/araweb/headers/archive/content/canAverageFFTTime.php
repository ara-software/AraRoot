<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canAverageFFTTime\"><h3>Average FFT v Time</h3></a>
<img style=\"border:outset\" src=\"$rundir/canAverageFFTTime.png\" alt=\"canAverageFFTTime\" />'";
?>
