<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canWaveformSNRTime\"><h3>Waveform SNR</h3></a>
<img style=\"border:outset\" src=\"$rundir/canWaveformSNRTime.png\" alt=\"canWaveformSNRTime\" />'";
?>
