<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canTrigTypeBit\"><h3>Trigger Type Bits</h3></a>
<img style=\"border:outset\" src=\"$rundir/canTrigTypeBit.png\" alt=\"canTrigTypeBit\" />'";
?>
