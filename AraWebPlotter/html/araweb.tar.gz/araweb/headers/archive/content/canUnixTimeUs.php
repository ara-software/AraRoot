<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canUnixTimeUs\"><h3>Sub Second Timing</h3></a>
<img style=\"border:outset\" src=\"$rundir/canUnixTimeUs.png\" alt=\"canUnixTimeUs\" />'";
?>
