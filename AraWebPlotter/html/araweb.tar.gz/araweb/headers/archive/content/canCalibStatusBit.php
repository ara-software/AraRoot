<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canCalibStatusBit\"><h3>Calibration Status Bits</h3></a>
<img style=\"border:outset\" src=\"$rundir/canCalibStatusBit.png\" alt=\"canCalibStatusBit\" />'";
?>
