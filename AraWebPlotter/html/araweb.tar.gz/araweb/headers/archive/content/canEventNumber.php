<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canEventNumber\"><h3>Event Number</h3></a>
<img style=\"border:outset\" src=\"$rundir/canEventNumber.png\" alt=\"canEventNumber\" />'";
?>
