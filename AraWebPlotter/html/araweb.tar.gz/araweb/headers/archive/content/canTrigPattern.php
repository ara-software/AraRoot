<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canTrigPattern\"><h3>Trigger Pattern</h3></a>
<img style=\"border:outset\" src=\"$rundir/canTrigPattern.png\" alt=\"canTrigPattern\" />'";
?>
