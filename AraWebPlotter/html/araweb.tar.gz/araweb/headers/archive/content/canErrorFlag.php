<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canErrorFlag\"><h3>Calibration Status Bits</h3></a>
<img style=\"border:outset\" src=\"$rundir/canErrorFlag.png\" alt=\"canErrorFlag\" />'";
?>
