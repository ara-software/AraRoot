<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canPriority\"><h3>Priority</h3></a>
<img style=\"border:outset\" src=\"$rundir/canPriority.png\" alt=\"canPriority\" />'";
?>
