<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canDeadTime\"><h3>Dead Time</h3></a>
<img style=\"border:outset\" src=\"$rundir/canDeadTime.png\" alt=\"canDeadTime\" />'";
?>
