<?php
require("utils.php");
doPage("content/canAverageFFT.php");
?>
