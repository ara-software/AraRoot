<?php
require("utils.php");
doPage("content/canWaveformRMSTime.php");
?>
