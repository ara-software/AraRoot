<?php
require("utils.php");
doPage("content/canAverageFFTTime.php");
?>
