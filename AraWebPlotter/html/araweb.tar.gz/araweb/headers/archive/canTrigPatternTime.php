<?php
require("utils.php");
doPage("content/canTrigPatternTime.php");
?>
