<?php
require("utils.php");
doPage("content/canDeadTime.php");
?>
