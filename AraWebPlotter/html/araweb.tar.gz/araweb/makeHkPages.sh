#!/bin/bash

../makePlotPage.sh canTemp "Temperature"
../makePlotPage.sh canRfpDiscone "RF Power Discone"
../makePlotPage.sh canRfpBatwing "RF Power Batwing"
../makePlotPage.sh canSclBatMinus "Scaler Batwing-"
../makePlotPage.sh canSclBatPlus "Scaler Batwing+"
../makePlotPage.sh canSclDiscone "Scaler Discone"
../makePlotPage.sh canSclGlobal "Scaler Global"
../makePlotPage.sh canSclTrigL1 "Scaler -- L1 Trigger"
../makePlotPage.sh canDac "DAC"
