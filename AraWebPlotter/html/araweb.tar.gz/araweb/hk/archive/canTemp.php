<?php
require("utils.php");
doPage("content/canTemp.php");
?>
