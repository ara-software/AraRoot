<?php
require("utils.php");
doPage("content/canSclGlobal.php");
?>
