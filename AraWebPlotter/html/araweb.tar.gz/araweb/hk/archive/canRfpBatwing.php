<?php
require("utils.php");
doPage("content/canRfpBatwing.php");
?>
