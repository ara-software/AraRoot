<?php
require("utils.php");
doPage("content/indexRun.php");
?>