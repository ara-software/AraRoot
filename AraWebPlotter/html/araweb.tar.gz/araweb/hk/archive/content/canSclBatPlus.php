<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canSclBatPlus\"><h3>Scalers -- Bat Plus</h3></a>
<img style=\"border:outset\" src=\"$rundir/canSclBatPlus.png\" alt=\"canSclBatPlus\" />'";
?>
