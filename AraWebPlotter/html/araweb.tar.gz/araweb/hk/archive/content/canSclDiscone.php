<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canSclDiscone\"><h3>Scalers -- Discone</h3></a>
<img style=\"border:outset\" src=\"$rundir/canSclDiscone.png\" alt=\"canSclDiscone\" />'";
?>
