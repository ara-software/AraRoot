<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canDac\"><h3>DAC</h3></a>
<img style=\"border:outset\" src=\"$rundir/canDac.png\" alt=\"canDac\" />'";
?>
