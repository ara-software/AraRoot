<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canRfpBatwing\"><h3>RF Power Batwing</h3></a>
<img style=\"border:outset\" src=\"$rundir/canRfpBatwing.png\" alt=\"canRfpBatwing\" />'";
?>
