<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canSclTrigL1\"><h3>Scalers -- L1 Trigger</h3></a>
<img style=\"border:outset\" src=\"$rundir/canSclTrigL1.png\" alt=\"canSclTrigL1\" />'";
?>
