<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canRfpDiscone\"><h3>RF Power -- Discone</h3></a>
<img style=\"border:outset\" src=\"$rundir/canRfpDiscone.png\" alt=\"canRfpDiscone\" />'";
?>
