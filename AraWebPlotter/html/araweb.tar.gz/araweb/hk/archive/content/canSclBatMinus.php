<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canSclBatMinus\"><h3>Scalers -- Bat Minus</h3></a>
<img style=\"border:outset\" src=\"$rundir/canSclBatMinus.png\" alt=\"canSclBatMinus\" />'";
?>
