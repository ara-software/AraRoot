<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canTemp\"><h3>Temperatures</h3></a>
<img style=\"border:outset\" src=\"$rundir/canTemp.png\" alt=\"canTemp\" />'";
?>
