<?php
$rundir=$_GET["rundir"];

echo "<a name=\"canSclGlobal\"><h3>Scalers -- Global</h3></a>
<img style=\"border:outset\" src=\"$rundir/canSclGlobal.png\" alt=\"canSclGlobal\" />'";
?>
