<?php
require("utils.php");
doPage("content/index.php");
?>