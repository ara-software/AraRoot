<?php
require("utils.php");
doPage("content/browseEvents.php");
?>