#!/bin/bash
cd events
../makePlotPage.sh canAverageFFT "Average Power Spectrum"
#../makePlotPage.sh lastEvent "Last Event"
#../makePlotPage.sh browseEvents "Browse Events"