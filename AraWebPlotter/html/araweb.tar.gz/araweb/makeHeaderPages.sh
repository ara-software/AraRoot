#!/bin/bash
cd headers
../makeHeaderPlotPage.sh canCalibStatusBit "Calibration Status Bits"
../makeHeaderPlotPage.sh canDeadTime "Dead Time"
../makeHeaderPlotPage.sh canErrorFlag "Error Flag"
../makeHeaderPlotPage.sh canEventNumber "Event Number"
../makeHeaderPlotPage.sh canPpsNum "PPS Number"
../makeHeaderPlotPage.sh canPriority "Priority"
../makeHeaderPlotPage.sh canRcoCount "RCO Count"
../makeHeaderPlotPage.sh canRoVdd "RoVdd"
../makeHeaderPlotPage.sh canTrigPattern "Trigger Pattern"
../makeHeaderPlotPage.sh canTrigTypeBit "Trig Type Bit"
